cp ../../../TFACCComputeServer/build/server .
cp ../../../TFACCComputeServer/launch.py .
cp -r ../../../TFACCComputeServer/driver .