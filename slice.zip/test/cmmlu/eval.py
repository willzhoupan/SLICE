import CMMLU.src.mp_utils as mp
import sys
print(mp.get_results(sys.argv[1]))
