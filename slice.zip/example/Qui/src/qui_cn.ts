<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>QObject</name>
    <message>
        <location filename="Qui.cpp" line="133"/>
        <source>Open Directory</source>
        <translation>打开目录</translation>
    </message>
    <message>
        <location filename="Qui.cpp" line="148"/>
        <source>Open File</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <location filename="Qui.cpp" line="149"/>
        <source>All Files (*)</source>
        <translation>所有文件 (*)</translation>
    </message>
</context>
<context>
    <name>Qui</name>
    <message>
        <location filename="Qui.cpp" line="77"/>
        <source>Write file error</source>
        <translation>保存文件错误</translation>
    </message>
    <message>
        <location filename="Qui.cpp" line="77"/>
        <source>Unable to write to specified location!</source>
        <translation>保存文件失败!</translation>
    </message>
    <message>
        <location filename="Qui.cpp" line="87"/>
        <location filename="Qui.cpp" line="91"/>
        <source>The input message cannot be empty!</source>
        <translation>输入信息不能为空！</translation>
    </message>
</context>
<context>
    <name>QuiClass</name>
    <message>
        <location filename="Qui.ui" line="14"/>
        <source>Qui</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Qui.ui" line="207"/>
        <source>top_k</source>
        <translation>采样参数top_k</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="221"/>
        <source>top_p</source>
        <translation>采样参数top_p</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="241"/>
        <source>repeat_penalty</source>
        <translation>重复惩罚</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="268"/>
        <source>temperature</source>
        <translation>温度</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="366"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="385"/>
        <source>Clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="411"/>
        <source>Reset</source>
        <translation>失忆</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="424"/>
        <source>Send</source>
        <translation>发送</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="460"/>
        <source>Setting</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="498"/>
        <source>Model Directory</source>
        <translation>模型所在目录</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="508"/>
        <location filename="Qui.ui" line="609"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Qui.ui" line="534"/>
        <source>Model</source>
        <translation>模型</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="560"/>
        <source>Qwen-1.5-7b-int8.flm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Qui.ui" line="565"/>
        <source>Qwen-1.5-4b-int8.flm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Qui.ui" line="570"/>
        <source>deepseek_coder-6.7b-ins-int8.flm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Qui.ui" line="575"/>
        <source>chatglm2-6b-int8.flm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Qui.ui" line="602"/>
        <source>fastllm.exe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Qui.ui" line="619"/>
        <source>Threads</source>
        <translation>线程数</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="641"/>
        <source>LowMemMode</source>
        <translation>低内存模式</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="662"/>
        <source>DeviceMap</source>
        <translation>多卡部署</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="722"/>
        <location filename="Qui.ui" line="758"/>
        <location filename="Qui.ui" line="794"/>
        <location filename="Qui.ui" line="830"/>
        <location filename="Qui.ui" line="866"/>
        <source>cpu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Qui.ui" line="727"/>
        <location filename="Qui.ui" line="763"/>
        <location filename="Qui.ui" line="799"/>
        <location filename="Qui.ui" line="835"/>
        <location filename="Qui.ui" line="871"/>
        <source>cuda:0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Qui.ui" line="732"/>
        <location filename="Qui.ui" line="768"/>
        <location filename="Qui.ui" line="804"/>
        <location filename="Qui.ui" line="840"/>
        <location filename="Qui.ui" line="876"/>
        <source>cuda:1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Qui.ui" line="737"/>
        <location filename="Qui.ui" line="773"/>
        <location filename="Qui.ui" line="809"/>
        <location filename="Qui.ui" line="845"/>
        <location filename="Qui.ui" line="881"/>
        <source>cuda:2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Qui.ui" line="742"/>
        <location filename="Qui.ui" line="778"/>
        <location filename="Qui.ui" line="814"/>
        <location filename="Qui.ui" line="850"/>
        <location filename="Qui.ui" line="886"/>
        <source>cuda:3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Qui.ui" line="931"/>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
    <message>
        <location filename="Qui.ui" line="938"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
</context>
</TS>
